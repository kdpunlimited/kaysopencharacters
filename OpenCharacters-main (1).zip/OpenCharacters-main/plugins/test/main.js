// This file is just for testing stuff
console.log("oc.thread.messages.length:", oc.thread.messages.length);
